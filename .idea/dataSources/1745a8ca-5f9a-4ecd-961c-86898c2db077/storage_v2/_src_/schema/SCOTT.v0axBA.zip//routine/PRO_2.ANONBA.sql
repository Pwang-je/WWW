create procedure pro_2(pid in person.id%type, pname in person.name%type)
is
begin
  update person set name=pname, weight=pweight
  where id=pid;
  commit;
exception when others then
  dbms_output.put_line('update error!');
  rollback;
end;
/

