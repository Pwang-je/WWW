create procedure pro_6
is
  cursor cur is 
              select id, name, weight
              from person;
  pid person.id%type;
  pid person.name%type;
  pid person.weight%type;
begin
  
  for plist in cur loop
    dbms_output.put_line(plist.id || ' ' || plist.name || ' ' || plist.weight );
  end loop; 
  
end;
/

