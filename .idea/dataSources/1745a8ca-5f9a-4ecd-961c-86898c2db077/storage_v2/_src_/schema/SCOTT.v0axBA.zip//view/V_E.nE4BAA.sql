create view V_E as
  SELECT	"JIKWON_NAME","YPAY"
	FROM		v_d
	WHERE		ypay >= 6000
/

