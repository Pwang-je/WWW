create procedure pro_3(pid in person.id%type)
is
begin
  delete from person 
  where id=pid;
  commit;
exception when others then
  dbms_output.put_line('delete error!');
  rollback;
end;
/

