create procedure p_a
is 
begin
  delete from jiktest
          where jikwon_no=1;
end;
/

