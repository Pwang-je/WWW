create view V_EXAM2 as
  SELECT	BUSER_NAME	AS	부서명,
					COUNT(*)		AS	직원수
	FROM		BUSER
		INNER JOIN JIKWON ON JIKWON.BUSER_NUM = BUSER_NO
		GROUP BY BUSER_NAME HAVING COUNT(*) = ( SELECT MAX(count(*))
																						FROM		JIKWON
																						GROUP BY BUSER_NUM)
/

